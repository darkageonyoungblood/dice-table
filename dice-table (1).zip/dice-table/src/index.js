/**
 * Dice table. Worker + Durable Object.
 *
 * The whole point of the server is enforcement. Two things cannot be done
 * in the browser and are done here instead:
 *
 *   1. Rolling. The die is rolled inside the Durable Object, so a player
 *      cannot edit a result on the way back. The client only animates a
 *      number it was given.
 *
 *   2. Visibility. A player socket is never sent another player's result.
 *      Hiding rolls with CSS or a client-side filter is not hiding them,
 *      because anything that reaches the browser can be read in devtools.
 */
import { DurableObject } from "cloudflare:workers";

/* ------------------------------------------------------------ randomness */

// 2^32 is not divisible by 20, so a raw modulo would favour the low faces.
// Discard draws landing in the short tail instead.
const LIMIT = Math.floor(0x100000000 / 20) * 20;

function d20() {
  const buf = new Uint32Array(1);
  let v;
  do {
    crypto.getRandomValues(buf);
    v = buf[0];
  } while (v >= LIMIT);
  return (v % 20) + 1;
}

// Unambiguous alphabet: no O/0, no I/1, no S/5.
const ALPHABET = "ABCDEFGHJKLMNPQRTUVWXYZ2346789";

function code(n) {
  const buf = new Uint32Array(n);
  crypto.getRandomValues(buf);
  let s = "";
  for (let i = 0; i < n; i++) s += ALPHABET[buf[i] % ALPHABET.length];
  return s;
}

function token() {
  const buf = new Uint8Array(24);
  crypto.getRandomValues(buf);
  return Array.from(buf, b => b.toString(16).padStart(2, "0")).join("");
}

// Constant-time-ish compare, so a wrong token cannot be found by timing.
function sameSecret(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

const MAX_SEATS = 12;
const MAX_LOG = 200;
const MAX_HISTORY = 40;

/* ------------------------------------------------------------ durable object */

export class Table extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.room = null;
    ctx.blockConcurrencyWhile(async () => {
      this.room = (await ctx.storage.get("room")) || null;
    });
  }

  save() {
    return this.ctx.storage.put("room", this.room);
  }

  newSeat(i) {
    return {
      id: i,
      code: code(4),
      name: `Player ${i + 1}`,
      mode: "norm",
      mod: 0,
      history: [],
    };
  }

  /** Called over RPC by the Worker before any socket is opened. */
  async create(roomCode, seats) {
    this.room = {
      code: roomCode,
      dmToken: token(),
      created: Date.now(),
      seats: Array.from({ length: clampSeats(seats) }, (_, i) => this.newSeat(i)),
      dmHistory: [],
      log: [],
    };
    await this.save();
    return { code: this.room.code, dmToken: this.room.dmToken };
  }

  async exists() {
    return !!this.room;
  }

  /** Check a seat code without opening a socket, so joining can fail cleanly. */
  async checkSeat(seatCode) {
    if (!this.room) return { ok: false, error: "That table does not exist." };
    const seat = this.room.seats.find(s => s.code === String(seatCode || "").toUpperCase());
    if (!seat) return { ok: false, error: "That seat code is not on this table." };
    return { ok: true, seat: seat.id, name: seat.name };
  }

  async fetch(request) {
    const url = new URL(request.url);
    const role = url.searchParams.get("role");
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);

    if (!this.room) return new Response("No such table", { status: 404 });

    let who;
    if (role === "dm") {
      if (!sameSecret(url.searchParams.get("token") || "", this.room.dmToken)) {
        return new Response("Bad DM token", { status: 403 });
      }
      who = { role: "dm" };
    } else {
      const seat = this.room.seats.find(
        s => s.code === (url.searchParams.get("seat") || "").toUpperCase());
      if (!seat) return new Response("Bad seat code", { status: 403 });
      who = { role: "player", seat: seat.id };
    }

    // Hibernation: the attachment survives eviction, so a woken object
    // still knows which socket belongs to whom.
    this.ctx.acceptWebSocket(server, [who.role === "dm" ? "dm" : `seat:${who.seat}`]);
    server.serializeAttachment(who);
    this.push(server, who);
    if (who.role === "player") this.pushDM();

    return new Response(null, { status: 101, webSocket: client });
  }

  /* ---------------------------------------------------------- projections */

  // What a DM is allowed to see: everything.
  dmView() {
    const connected = new Set();
    for (const ws of this.ctx.getWebSockets()) {
      const a = ws.deserializeAttachment();
      if (a && a.role === "player") connected.add(a.seat);
    }
    return {
      t: "dm",
      code: this.room.code,
      seats: this.room.seats.map(s => ({
        id: s.id, code: s.code, name: s.name, mode: s.mode, mod: s.mod,
        connected: connected.has(s.id),
        last: s.history[0] || null,
      })),
      dmHistory: this.room.dmHistory,
      log: this.room.log,
    };
  }

  // What a player is allowed to see: their own seat, and nothing else.
  // No other seat's name, mode, or result is present in this object.
  playerView(seatId) {
    const s = this.room.seats[seatId];
    return {
      t: "me",
      code: this.room.code,
      seat: { id: s.id, name: s.name, mode: s.mode, mod: s.mod, history: s.history },
    };
  }

  push(ws, who) {
    try {
      ws.send(JSON.stringify(
        who.role === "dm" ? this.dmView() : this.playerView(who.seat)));
    } catch { /* socket already gone */ }
  }

  pushDM() {
    const v = JSON.stringify(this.dmView());
    for (const ws of this.ctx.getWebSockets("dm")) {
      try { ws.send(v); } catch { /* ignore */ }
    }
  }

  pushSeat(seatId) {
    const v = JSON.stringify(this.playerView(seatId));
    for (const ws of this.ctx.getWebSockets(`seat:${seatId}`)) {
      try { ws.send(v); } catch { /* ignore */ }
    }
  }

  /* ---------------------------------------------------------- rolling */

  resolve(mode, mod) {
    const a = d20();
    const b = mode === "norm" ? null : d20();
    let kept = a, dropped = null;
    if (b !== null) {
      kept = mode === "adv" ? Math.max(a, b) : Math.min(a, b);
      dropped = kept === a ? b : a;
    }
    return { kept, dropped, mode, mod, total: kept + mod, ts: Date.now() };
  }

  rollSeat(seatId) {
    const s = this.room.seats[seatId];
    if (!s) return;
    const r = this.resolve(s.mode, s.mod);
    s.history.unshift(r);
    s.history.splice(MAX_HISTORY);
    this.room.log.unshift({ ...r, seat: s.id, name: s.name });
    this.room.log.splice(MAX_LOG);
    this.save();
    this.pushSeat(seatId);
    this.pushDM();
  }

  /* ---------------------------------------------------------- messages */

  async webSocketMessage(ws, raw) {
    const who = ws.deserializeAttachment();
    if (!who || !this.room) return;

    let m;
    try { m = JSON.parse(raw); } catch { return; }

    if (who.role === "player") {
      const s = this.room.seats[who.seat];
      if (!s) return;
      if (m.t === "roll") {
        this.rollSeat(who.seat);
      } else if (m.t === "name" && typeof m.name === "string") {
        s.name = m.name.slice(0, 24).trim() || s.name;
        await this.save();
        this.pushSeat(who.seat);
        this.pushDM();
      }
      // A player asking to change their own mode is ignored on purpose.
      // Advantage is the DM's call.
      return;
    }

    // ---- DM only past this point
    switch (m.t) {
      case "mode": {
        const s = this.room.seats[m.seat];
        if (s && ["norm", "adv", "dis"].includes(m.mode)) {
          s.mode = m.mode;
          await this.save();
          this.pushSeat(s.id);
          this.pushDM();
        }
        break;
      }
      case "modeAll": {
        if (!["norm", "adv", "dis"].includes(m.mode)) break;
        for (const s of this.room.seats) s.mode = m.mode;
        await this.save();
        for (const s of this.room.seats) this.pushSeat(s.id);
        this.pushDM();
        break;
      }
      case "mod": {
        const s = this.room.seats[m.seat];
        if (s && Number.isFinite(m.mod)) {
          s.mod = Math.max(-20, Math.min(20, Math.trunc(m.mod)));
          await this.save();
          this.pushSeat(s.id);
          this.pushDM();
        }
        break;
      }
      case "seats": {
        const n = clampSeats(m.n);
        const cur = this.room.seats.length;
        if (n > cur) {
          for (let i = cur; i < n; i++) this.room.seats.push(this.newSeat(i));
        } else if (n < cur) {
          this.room.seats.length = n;
        }
        await this.save();
        this.pushDM();
        break;
      }
      case "rollFor":
        this.rollSeat(m.seat);
        break;
      case "rollDM": {
        const r = this.resolve(
          ["norm", "adv", "dis"].includes(m.mode) ? m.mode : "norm",
          Number.isFinite(m.mod) ? Math.trunc(m.mod) : 0);
        this.room.dmHistory.unshift(r);
        this.room.dmHistory.splice(MAX_HISTORY);
        await this.save();
        this.pushDM();
        break;
      }
      case "clear":
        for (const s of this.room.seats) s.history = [];
        this.room.log = [];
        this.room.dmHistory = [];
        await this.save();
        for (const s of this.room.seats) this.pushSeat(s.id);
        this.pushDM();
        break;
    }
  }

  async webSocketClose(ws) {
    try { ws.close(); } catch { /* ignore */ }
    this.pushDM();
  }

  async webSocketError(ws) {
    this.pushDM();
  }
}

function clampSeats(n) {
  n = Math.trunc(Number(n) || 4);
  return Math.max(1, Math.min(MAX_SEATS, n));
}

/* ------------------------------------------------------------ worker */

const json = (obj, status = 200) => new Response(JSON.stringify(obj), {
  status, headers: { "content-type": "application/json" },
});

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/create" && request.method === "POST") {
      const body = await request.json().catch(() => ({}));
      const roomCode = code(5);
      const stub = env.TABLE.getByName(roomCode);
      const made = await stub.create(roomCode, body.seats);
      return json(made);
    }

    if (url.pathname === "/api/seat" && request.method === "POST") {
      const body = await request.json().catch(() => ({}));
      const roomCode = String(body.code || "").toUpperCase();
      if (!/^[A-Z2-9]{5}$/.test(roomCode)) {
        return json({ ok: false, error: "That table code does not look right." }, 400);
      }
      const stub = env.TABLE.getByName(roomCode);
      if (!(await stub.exists())) {
        return json({ ok: false, error: "No table with that code." }, 404);
      }
      return json(await stub.checkSeat(body.seat));
    }

    if (url.pathname === "/ws") {
      if (request.headers.get("Upgrade") !== "websocket") {
        return new Response("Expected websocket", { status: 426 });
      }
      const roomCode = (url.searchParams.get("code") || "").toUpperCase();
      if (!/^[A-Z2-9]{5}$/.test(roomCode)) {
        return new Response("Bad table code", { status: 400 });
      }
      return env.TABLE.getByName(roomCode).fetch(request);
    }

    // Anything else is a static asset.
    return env.ASSETS.fetch(request);
  },
};
